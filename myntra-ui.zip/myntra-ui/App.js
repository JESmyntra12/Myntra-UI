import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, Modal, StyleSheet, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ProfileScreen from './ProfileScreen'; // Assuming ProfileScreen is in the same directory
import SelectPhotoScreen from './SelectPhotoScreen';



const Stack = createStackNavigator();

const HomeScreen = ({ navigation }) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [hoveredOption, setHoveredOption] = useState(null);

  const handleIconClick = () => {
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
  };

  const handleStyleForTheDay = () => {
    setModalVisible(false);
    navigation.navigate('Profile');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>fwd</Text>
        <Ionicons name="search" size={24} color="black" />
        <Text>Become Insider</Text>
        <Ionicons name="heart" size={24} color="black" />
        <Ionicons name="notifications" size={24} color="black" />
        <Ionicons name="person" size={24} color="black" />
      </View>
      <View style={styles.searchBar}>
        <Text style={styles.searchText}>Search for brands and products</Text>
        <TouchableOpacity style={styles.iconContainer} onPress={handleIconClick}>
          <Ionicons name="pencil" size={24} color="black" />
        </TouchableOpacity>
      </View>
      <View style={styles.tabs}>
        <Text style={styles.tabText}>Men</Text>
        <Text style={styles.tabText}>Women</Text>
      </View>
      <View style={styles.promoContainer}>
        <Image
          source={require('./assets/promo-image.jpg')} // Replace with your local asset
          style={styles.promoImage}
        />
        <Text style={styles.promoText}>fwd Fresh Drops Just Dropped SHOP NOW</Text>
      </View>

      <Modal
        transparent={true}
        animationType="slide"
        visible={modalVisible}
        onRequestClose={closeModal}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Pressable
              style={[
                styles.modalOption,
                hoveredOption === 'draw' && styles.hoveredOption,
              ]}
              onPress={closeModal}
              onMouseEnter={() => setHoveredOption('draw')}
              onMouseLeave={() => setHoveredOption(null)}
            >
              <Text style={styles.modalText}>Draw and search the product</Text>
            </Pressable>
            <Pressable
              style={[
                styles.modalOption,
                hoveredOption === 'style' && styles.hoveredOption,
              ]}
              onPress={handleStyleForTheDay}
              onMouseEnter={() => setHoveredOption('style')}
              onMouseLeave={() => setHoveredOption(null)}
            >
              <Text style={styles.modalText}>Style for the Day</Text>
            </Pressable>
            <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
              <Ionicons name="close" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Profile" component={ProfileScreen} />
        <Stack.Screen name="SelectPhoto" component={SelectPhotoScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  searchBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
  },
  searchText: {
    color: '#999',
  },
  iconContainer: {
    padding: 5,
  },
  tabs: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  tabText: {
    fontSize: 18,
  },
  promoContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  promoImage: {
    width: '100%',
    height: 400, // Increased height for a longer image
    borderRadius: 10,
  },
  promoText: {
    marginTop: 10,
    fontSize: 18,
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: 300,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
  },
  modalOption: {
    marginTop: 10,
    padding: 10,
    borderRadius: 5,
  },
  hoveredOption: {
    backgroundColor: '#e0e0e0',
  },
  modalText: {
    fontSize: 18,
  },
  closeButton: {
    marginTop: 20,
  },
});
